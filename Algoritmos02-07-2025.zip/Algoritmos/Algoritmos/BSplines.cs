﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Algoritmos
{
    public class BSplines
    {

        public static void CalcularCurvaBSpline(PictureBox picCanvas,List<PointF> puntosControl, int grado, List<double> knots, int resolucion = 100)
        {
            List<PointF> puntosCurva = new List<PointF>();

            int n = puntosControl.Count - 1;
            int m = knots.Count - 1;

            double tInicio = knots[grado];
            double tFin = knots[m - grado];

            for (int step = 0; step <= resolucion-1; step++)
            {
                double t = tInicio + (tFin - tInicio) * step / resolucion;

                float x = 0;
                float y = 0;

                for (int i = 0; i <= n; i++)
                {
                    double b = BaseBSpline(i, grado, t, knots);
                    x += (float)(b * puntosControl[i].X);
                    y += (float)(b * puntosControl[i].Y);
                }

                puntosCurva.Add(new PointF(x, y));
            }

            DibujarLineaBSplines(picCanvas, puntosCurva);
        }

        public static void DibujarLineaBSplines(PictureBox picCanvas, List<PointF> puntos)
        {
            Graphics graphics;
            Pen pen = new Pen(Color.Black, 2);
            graphics = picCanvas.CreateGraphics();
            graphics.DrawLines(pen, puntos.ToArray());

        }
        //Función base recursiva de B-spline (Cox–de Boor)

        private static double BaseBSpline(int i, int p, double t, List<double> knots)
        {
            if (p == 0)
            {
                return (t >= knots[i] && t < knots[i + 1]) ? 1.0 : 0.0;
            }

            double denom1 = knots[i + p] - knots[i];
            double denom2 = knots[i + p + 1] - knots[i + 1];

            double term1 = denom1 == 0 ? 0 : (t - knots[i]) / denom1 * BaseBSpline(i, p - 1, t, knots);
            double term2 = denom2 == 0 ? 0 : (knots[i + p + 1] - t) / denom2 * BaseBSpline(i + 1, p - 1, t, knots);

            return term1 + term2;
        }


        //Genera un vector de nudos uniforme abierto para B-spline

        public static List<double> GenerarNudosUniformes(int numPuntos, int grado)
        {
            int n = numPuntos - 1;
            int m = n + grado + 1;
            List<double> knots = new List<double>();

            for (int i = 0; i <= m; i++)
            {
                if (i < grado)
                    knots.Add(0);
                else if (i <= m - grado)
                    knots.Add(i - grado);
                else
                    knots.Add(m - 2 * grado);
            }

            return knots;
        }
    }
}

