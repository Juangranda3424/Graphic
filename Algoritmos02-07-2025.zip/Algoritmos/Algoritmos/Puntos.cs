﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Algoritmos
{
    public class Puntos
    {
        public float X { get; set; }
        public float Y { get; set; }

        public Puntos(float x, float y)
        {
            X = x;
            Y = y;
        }

    }
}
