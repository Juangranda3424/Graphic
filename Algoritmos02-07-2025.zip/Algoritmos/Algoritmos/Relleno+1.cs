﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Algoritmos
{
    public class Relleno_1
    {

        class Edge
        {
            public int YMax;
            public float X;
            public float InverseSlope;
            private RellenoFigura relleno = new RellenoFigura();

            public Edge(int yMax, float x, float invSlope)
            {
                YMax = yMax;
                X = x;
                InverseSlope = invSlope;
            }
        }

        public static List<Point> DibujarPoligono(PictureBox picCanvas, Point centro, int radio, int lados)
        {
            Graphics g = picCanvas.CreateGraphics();
            Pen pen = new Pen(Color.Black, 3);
            List<Point> puntos = new List<Point>();
            for (int i = 0; i < lados; i++)
            {
                double angulo = i * 2 * Math.PI / lados - Math.PI / 2;
                float x = centro.X + radio * (float)Math.Cos(angulo);
                float y = centro.Y + radio * (float)Math.Sin(angulo);
                puntos.Add(new Point((int)x, (int)y));
            }

            g.DrawPolygon(pen, puntos.ToArray());
            return puntos;
        }

        public static void FillPolygon(PictureBox picCanvas,List<Point> vertices, Color fillColor)
        {
            // Crear la Edge Table
            Dictionary<int, List<Edge>> edgeTable = new Dictionary<int, List<Edge>>();

            Graphics g = picCanvas.CreateGraphics();

            int n = vertices.Count;
            for (int i = 0; i < n; i++)
            {
                Point p1 = vertices[i];
                Point p2 = vertices[(i + 1) % n];

                if (p1.Y == p2.Y) continue; // ignorar aristas horizontales

                Point lower = p1.Y < p2.Y ? p1 : p2;
                Point upper = p1.Y > p2.Y ? p1 : p2;

                float invSlope = (float)(upper.X - lower.X) / (upper.Y - lower.Y);
                Edge edge = new Edge(upper.Y, lower.X, invSlope);

                if (!edgeTable.ContainsKey(lower.Y))
                    edgeTable[lower.Y] = new List<Edge>();

                edgeTable[lower.Y].Add(edge);
            }

            // Buscar el Y mínimo
            int scanline = int.MaxValue;
            foreach (var key in edgeTable.Keys)
                if (key < scanline) scanline = key;

            List<Edge> activeEdgeTable = new List<Edge>();

            while (edgeTable.Count > 0 || activeEdgeTable.Count > 0)
            {
                // 1. Agregar aristas a la AET
                if (edgeTable.ContainsKey(scanline))
                {
                    activeEdgeTable.AddRange(edgeTable[scanline]);
                    edgeTable.Remove(scanline);
                }

                // 2. Eliminar aristas donde YMax == scanline
                activeEdgeTable.RemoveAll(e => e.YMax == scanline);

                // 3. Ordenar AET por X
                activeEdgeTable.Sort((a, b) => a.X.CompareTo(b.X));

                // 4. Rellenar entre pares
                for (int i = 0; i < activeEdgeTable.Count - 1; i += 2)
                {
                    int xStart = (int)Math.Ceiling(activeEdgeTable[i].X);
                    int xEnd = (int)Math.Floor(activeEdgeTable[i + 1].X);

                    for (int x = xStart; x <= xEnd; x++)
                    {
                        g.FillRectangle(new SolidBrush(fillColor), x, scanline, 1, 1);
                    }
                }

                // 5. Incrementar Y
                scanline++;

                // 6. Actualizar X para cada arista activa
                foreach (var edge in activeEdgeTable)
                {
                    edge.X += edge.InverseSlope;
                }
            }
        }
    }
}
