﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Algoritmos
{
    public partial class DDAGrafico : Form
    {
        private CohenSutherland cohen;
        float Xpunto1 = 0;
        float Ypunto1 = 0;
        float Xpunto2 = 0;
        float Ypunto2 = 0;
        List<PointF> puntos = new List<PointF>();
        bool cohenSutherlandLinea = false;
        bool sutherlandHodgmanPoligono = false;
        bool CurvaBezier = false;
        bool Bsplines = false;
        private int CurvaBezierContadorPuntos = 0;
        public DDAGrafico()
        {
            InitializeComponent();
            radio.Visible = false;
            label3.Visible = false;
            resetear.FlatStyle = FlatStyle.Flat;
            resetear.FlatAppearance.BorderSize = 0;
            resetear.BackColor = Color.Black;
            button10.Visible = false;
        }

        private DDA dda = new DDA();
        private BresenhamLinea bresenhamLinea = new BresenhamLinea();
        private BresenhamCircunferencia bresenhamCircunferencia = new BresenhamCircunferencia();
        private RellenoFigura relleno = new RellenoFigura();
        private BresenhamElipse bresenhamElipse = new BresenhamElipse();
        private CurvasBezier curvasBezier = new CurvasBezier();
        private void CargarDatos()
        {


            dataGrid.ColumnCount = 2;
            dataGrid.ColumnHeadersVisible = true;
            DataGridViewCellStyle columnHeaderStyle = new DataGridViewCellStyle();

            columnHeaderStyle.BackColor = Color.Beige;
            columnHeaderStyle.Font = new Font("Verdana", 10, FontStyle.Bold);
            dataGrid.ColumnHeadersDefaultCellStyle = columnHeaderStyle;

            //No permite modificar, eliminar y que se añada
            dataGrid.AllowUserToAddRows = false;
            dataGrid.AllowUserToDeleteRows = false;
            dataGrid.ReadOnly = true;

            //Quita la columna que aparece a la izquierda
            dataGrid.RowHeadersVisible = false;
            dataGrid.Columns[0].Name = "X";
            dataGrid.Columns[1].Name = "Y";
            dataGrid.Columns[0].Width = dataGrid.Width / 2;
            dataGrid.Columns[1].Width = dataGrid.Width / 2;

        }

        private void LimpiarPantalla()
        {
            //Algoritmos CohenSutherland
            Xpunto1 = 0;
            Ypunto1 = 0;
            Xpunto2 = 0;
            Ypunto2 = 0;
            puntos.Clear();
            sutherlandHodgmanPoligono = false;
            cohenSutherlandLinea = false;
            Bsplines = false;
            CurvaBezier = false;
            //Limpiar DataGridView
            dataGrid.Rows.Clear();
            dataGrid.Columns.Clear();
            //Limpiar PictureBox
            picCanva.Image = null;
            picCanva.Refresh();
            //Limpiar Campos 
            txtX1.Text = "";
            txtX2.Text = "";
            txtY1.Text = "";
            txtY2.Text = "";
            CargarDatos();
        }

        private void ControlesVisiblesBresenhamCirculo()
        {
            radio.Visible = true;
            y2.Visible = false;
            x2.Visible = false;
            txtY2.Visible = false;
            label2.Visible = true;
            label3.Visible = false;
            txtY1.Visible = true;
            txtX2.Visible = true;
            label1.Visible = true;
            sutherlandHodgmanPoligono = false;
            cohenSutherlandLinea = false;
            txtX1.Visible = true;
            CurvaBezier = false;
            Bsplines = false;
        }

        private void ControlesVisiblesBresenhamLineaDDA()
        {
            radio.Visible = false;
            y2.Visible = true;
            x2.Visible = true;
            txtY2.Visible = true;
            label2.Visible = true;
            label1.Visible = true;
            txtY1.Visible = true;
            txtX2.Visible = true;
            label3.Visible = false;
            sutherlandHodgmanPoligono = false;
            cohenSutherlandLinea = false;
            txtX1.Visible = true;
            button10.Visible = false;
            CurvaBezier = false;
            Bsplines = false;
        }

        private void ControlesVisiblesCohenSutherlandLinea()
        {
            radio.Visible = false;
            y2.Visible = false;
            x2.Visible = false;
            txtY2.Visible = false;
            label2.Visible = false;
            label1.Visible = false;
            txtY1.Visible = false;
            txtX2.Visible = false;
            label3.Visible = false;
            sutherlandHodgmanPoligono = false;
            cohenSutherlandLinea = false;
            txtX1.Visible = false;
            button10.Visible = false;
        }

        private void ControlesVisiblesCohenSutherlandPoligono()
        {
            radio.Visible = false;
            y2.Visible = false;
            x2.Visible = false;
            txtY2.Visible = false;
            label2.Visible = false;
            label1.Visible = false;
            txtY1.Visible = false;
            txtX2.Visible = false;
            label3.Visible = false;
            sutherlandHodgmanPoligono = false;
            cohenSutherlandLinea = false;
            txtX1.Visible = false;
            button10.Visible = true;
            CurvaBezier = false;
            Bsplines = false;
        }

        private void ControlesVisiblesRelleno()
        {
            label2.Visible = true;
            radio.Visible = false;
            y2.Visible = false;
            x2.Visible = false;
            txtY2.Visible = false;
            label1.Visible = false;
            label2.Visible = false;
            txtY1.Visible = false;
            txtX2.Visible = false;
            label3.Visible = true;
            sutherlandHodgmanPoligono = false;
            cohenSutherlandLinea = false;
            txtX1.Visible = true;
            button10.Visible = false;
            CurvaBezier = false;
            Bsplines = false;
        }



        private void INICIAR_Click(object sender, EventArgs e)
        {
            try
            {
                ControlesVisiblesBresenhamLineaDDA();
                dda.CargarDatos(txtX1, txtY1, txtX2, txtY2);
                //Limpiar Puntos
                dda.puntos.Clear();
                //Llenar dataos
                dda.Puntos();
                LimpiarPantalla();
                foreach (var punto in dda.puntos)
                {
                    dataGrid.Rows.Add(punto.X, punto.Y);
                    dda.Dibujar(picCanva, punto.X, punto.Y);
                }
            }
            catch
            {
                MessageBox.Show("Ingrese todos los datos correctamente");
            }

        }


        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                ControlesVisiblesBresenhamLineaDDA();
                bresenhamLinea.puntos.Clear();
                bresenhamLinea.CargarDatos(txtX1, txtY1, txtX2, txtY2);
                bresenhamLinea.CrearPunto();
                LimpiarPantalla();
                foreach (var punto in bresenhamLinea.puntos)
                {
                    dataGrid.Rows.Add(punto.X, punto.Y);
                    bresenhamLinea.Dibujar(picCanva, punto.X, punto.Y);
                }
            }
            catch
            {
                MessageBox.Show("Ingrese todos los datos correctamente");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                ControlesVisiblesBresenhamCirculo();
                bresenhamCircunferencia.puntos.Clear();
                bresenhamCircunferencia.CargarDatos((float)picCanva.Width/2f+float.Parse(txtX1.Text), (float)picCanva.Height / 2f + float.Parse(txtY1.Text), float.Parse(txtX2.Text));
                bresenhamCircunferencia.ProcesoIterativo();
                LimpiarPantalla();
                foreach (var punto in bresenhamCircunferencia.puntos)
                {
                    dataGrid.Rows.Add(punto.X, punto.Y);
                    bresenhamCircunferencia.Dibujar(picCanva, punto.X, punto.Y);
                }
            }
            catch
            {
                MessageBox.Show("Ingrese todos los datos correctamente");
            }

        }

        private void resetear_Click(object sender, EventArgs e)
        {
            LimpiarPantalla();
            puntos.Clear();
        }

        private  async void button3_Click(object sender, EventArgs e)
        {
            float ancho = picCanva.Width / 2;
            float alto = picCanva.Height / 2;
            ControlesVisiblesRelleno();
            if (string.IsNullOrWhiteSpace(txtX1.Text))
            {
                LimpiarPantalla();
                MessageBox.Show("Ingrese todos los datos correctamente");
                return;
            }

            int lados = int.Parse(txtX1.Text);
            if (lados < 3)
            {
                LimpiarPantalla();
                MessageBox.Show("Ingrese un número mayor o igual a 3");
                return;
            }

            relleno.CalcularPuntos(picCanva, lados, ancho, alto);
            await relleno.RellenarAnimado(picCanva, (int)ancho, (int)alto, Color.Yellow);
            foreach (var punto in relleno.cola)
            {
                dataGrid.Rows.Add(punto.X, punto.Y);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                ControlesVisiblesBresenhamCirculo();
                bresenhamElipse.puntos.Clear();
                bresenhamElipse.CargarDatos((float)picCanva.Width / 2f + float.Parse(txtX1.Text), (float)picCanva.Height / 2f + float.Parse(txtY1.Text), float.Parse(txtX2.Text));
                bresenhamElipse.ProcesoIterativo();
                LimpiarPantalla();
                foreach (var punto in bresenhamElipse.puntos)
                {
                    dataGrid.Rows.Add(punto.X, punto.Y);
                    bresenhamElipse.Dibujar(picCanva, punto.X, punto.Y);
                }
            }
            catch
            {
                MessageBox.Show("Ingrese todos los datos correctamente");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int ancho = picCanva.Width / 2;
            int alto = picCanva.Height / 2;
            ControlesVisiblesRelleno();
            if (string.IsNullOrWhiteSpace(txtX1.Text))
            {
                LimpiarPantalla();
                MessageBox.Show("Ingrese todos los datos correctamente");
                return;
            }

            int lados = int.Parse(txtX1.Text);
            if (lados < 3)
            {
                LimpiarPantalla();
                MessageBox.Show("Ingrese un número mayor o igual a 3");
                return;
            }

            List<Point> puntos = Relleno_1.DibujarPoligono(picCanva, new Point(ancho, alto),60,lados);


            foreach (var punto in puntos.ToArray())
            {
                dataGrid.Rows.Add(punto.X, punto.Y);
            }
            Relleno_1.FillPolygon(picCanva, puntos, Color.Blue);

        }

        private void CargarImagen()
        {
            float x1 = picCanva.Width / 3;
            float y1 = picCanva.Height / 3;
            float x2 = picCanva.Width / 3 + picCanva.Width / 3;
            float y2 = picCanva.Height / 3;
            float x3 = picCanva.Width / 3;
            float y3 = picCanva.Height / 3 + picCanva.Height / 3;
            float x4 = picCanva.Width / 3 + picCanva.Width / 3;
            float y4 = picCanva.Height / 3 + picCanva.Height / 3;
            cohen = new CohenSutherland(x1, y1, x2, y2, x3, y3, x4, y4);
            cohen.DibujarFigura(picCanva);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ControlesVisiblesCohenSutherlandLinea();
            LimpiarPantalla();
            CargarImagen();
            cohenSutherlandLinea = true;
            sutherlandHodgmanPoligono = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ControlesVisiblesCohenSutherlandPoligono();
            LimpiarPantalla();
            CargarImagen();
            sutherlandHodgmanPoligono = true;
            cohenSutherlandLinea = false;
        }

        private void picCanva_MouseClick(object sender, MouseEventArgs e)
        {
            //Para Curva BSplines
            if (CurvaBezier)
            {
                puntos.Add(new PointF(e.X, e.Y));
                curvasBezier.DibujarPuntosUsuario(picCanva, puntos[CurvaBezierContadorPuntos]);
                CurvaBezierContadorPuntos++;
            }

            if (Bsplines)
            {
                puntos.Add(new PointF(e.X, e.Y));
                curvasBezier.DibujarPuntosUsuario(picCanva, puntos[CurvaBezierContadorPuntos]);
                CurvaBezierContadorPuntos++;
            }

            //Para dibujar el poligono

            if (sutherlandHodgmanPoligono)
            {
                puntos.Add(new PointF(e.X, e.Y));

                if (puntos.Count >= 3)
                {
                    picCanva.Refresh();
                    cohen.DibujarPoligono(picCanva, puntos.ToArray());
                }
            }

            if (cohenSutherlandLinea)
            {
                float auxX = e.X;
                float auxY = e.Y;
                if (Xpunto1 == 0 && Ypunto1 == 0)
                {
                    Xpunto1 = auxX;
                    Ypunto1 = auxY;
                }
                else
                {
                    Xpunto2 = auxX;
                    Ypunto2 = auxY;
                    cohen.CalcularLinea(picCanva, Xpunto1, Ypunto1, Xpunto2, Ypunto2);
                    Xpunto1 = 0;
                    Ypunto1 = 0;
                    Xpunto2 = 0;
                    Ypunto2 = 0;
                }
            }

        }

        private void button8_Click(object sender, EventArgs e)
        {
            ControlesVisiblesCohenSutherlandLinea();
            CurvaBezier = true;
            if (CurvaBezierContadorPuntos >= 3)
            {
                curvasBezier.IngresoPuntos(picCanva, puntos);
                CurvaBezierContadorPuntos = 0;
                puntos.Clear();
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            picCanva.Refresh();
            cohen.RecortarFigura(picCanva, puntos.ToArray());
        }

        private void button9_Click(object sender, EventArgs e)
        {
            ControlesVisiblesCohenSutherlandLinea();
            Bsplines = true;
            if (CurvaBezierContadorPuntos >= 3)
            {
                int grado = 3;
                var nudos = BSplines.GenerarNudosUniformes(puntos.Count, grado);

                BSplines.CalcularCurvaBSpline(picCanva,puntos, grado, nudos, 100); 
                CurvaBezierContadorPuntos = 0;
                puntos.Clear();
            }


        }
    }
}
