﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Algoritmos
{
    public class CurvasBezier
    {
        private List<PointF> puntosIngreso = new List<PointF>();
        private List<PointF> puntosItermedios = new List<PointF>();
        private float[] t = { 0f, 0.1f, 0.2f, 0.3f, 0.4f, 0.5f, 0.6f, 0.7f, 0.8f, 0.9f, 1f };
        private Graphics graphics;
        private Pen pen = new Pen(Color.Black, 2);

        public void IngresoPuntos(PictureBox picCanvas, List<PointF> puntosUsuario)
        {
            puntosIngreso = puntosUsuario;
            CalcularPuntosIntermedios();
            DibujarLineaBSplines(picCanvas);
        }

        public void CalcularPuntosIntermedios()
        {
            puntosItermedios.Clear();

            int n = puntosIngreso.Count - 1; // Grado de la curva

            for (int j = 0; j < t.Length; j++)
            {
                float tVal = t[j];
                float oneMinusT = 1 - tVal;

                float x = 0;
                float y = 0;

                for (int i = 0; i <= n; i++)
                {
                    float coefBinomial = BinomialCoefficient(n, i);
                    float term = coefBinomial * (float)Math.Pow(oneMinusT, n - i) * (float)Math.Pow(tVal, i);
                    x += term * puntosIngreso[i].X;
                    y += term * puntosIngreso[i].Y;
                }

                puntosItermedios.Add(new PointF(x, y));
            }
        }

        private float BinomialCoefficient(int n, int k)
        {
            return Factorial(n) / (Factorial(k) * Factorial(n - k));
        }

        private float Factorial(int n)
        {
            float result = 1;
            for (int i = 2; i <= n; i++)
                result *= i;
            return result;
        }


        public void DibujarPuntosUsuario(PictureBox picCanvas, PointF puntosUsuario)
        {
            graphics = picCanvas.CreateGraphics();
            graphics.DrawEllipse(pen, puntosUsuario.X - 2f, puntosUsuario.Y - 2f, 2, 2);
        }

        public void DibujarLineaBSplines(PictureBox picCanvas)
        {
            graphics = picCanvas.CreateGraphics();
            graphics.DrawLines(pen, puntosItermedios.ToArray());

        }
    }
}
