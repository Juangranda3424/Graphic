﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Algoritmos
{
    public class CohenSutherland
    {
        private float Xmin;
        private float Xmax;
        private float Ymin;
        private float Ymax;
        private string code1;
        private string code2;
        private float pendiente;


        Graphics graphics;
        Pen pen = new Pen(Color.Black, 2);
        List<PointF> pointF = new List<PointF>();

        //Arreglo de puntos para dibujar el Poligono recortado

        List<PointF> puntosPoligonoRecortado = new List<PointF>();


        public CohenSutherland(float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4)
        {
            Xmin = x1;
            Xmax = x2;
            Ymin = y1;
            Ymax = y3;

            pointF.Add(new PointF(x1, y1));
            pointF.Add(new PointF(x2, y2));
            pointF.Add(new PointF(x3, y3));
            pointF.Add(new PointF(x4, y4));
        }

        public void DibujarFigura(PictureBox picCanvas)
        {
            //Rectangulo

            //MessageBox.Show(Xmin + "," + Xmax + "  " + Ymin + "," + Ymax);

            graphics = picCanvas.CreateGraphics();
            graphics.DrawLine(pen, pointF[0], pointF[1]);
            graphics.DrawLine(pen, pointF[0], pointF[2]);
            graphics.DrawLine(pen, pointF[2], pointF[3]);
            graphics.DrawLine(pen, pointF[3], pointF[1]);

        }

        public void DibujarLinea(PictureBox picCanvas, float x1, float y1, float x2, float y2)
        {
            graphics.DrawLine(pen, new PointF(x1, y1), new PointF(x2, y2));
        }

        public void CalcularPendiente(float x1, float y1, float x2, float y2)
        {
            pendiente = (y2 - y1) / (x2 - x1);
        }

        public string CalcularCodigo(float x, float y)
        {
            string code = "";
            code += (y > Ymax) ? "1" : "0";
            code += (y < Ymin) ? "1" : "0";
            code += (x > Xmax) ? "1" : "0";
            code += (x < Xmin) ? "1" : "0";
            return code;
        }


        //Calculo los puntos para la linea y la dibujo
        public void CalcularLinea(PictureBox picCanvas, float x1, float y1, float x2, float y2)
        {
            code1 = CalcularCodigo(x1, y1);
            code2 = CalcularCodigo(x2, y2);

            //MessageBox.Show(code1 + " - " + code2);

            CalcularPendiente(x1, y1, x2, y2);

            List<PointF> ListaCoordenada = new List<PointF>();

            if (code1 == "0000" && code2 == "0000")
            {
                DibujarLinea(picCanvas, x1, y1, x2, y2);
                return;
            }

            for (int i = 0; i < 4; i++)
            {
                if (code1[i] == '1' && code2[i] == '1')
                {
                    //MessageBox.Show(code1 + " - " + code2);
                    return;
                }
            }

            ListaCoordenada.Add(CalcularPuntos(code1, x1, y1));
            ListaCoordenada.Add(CalcularPuntos(code2, x2, y2));

            DibujarLinea(picCanvas, ListaCoordenada[0].X, ListaCoordenada[0].Y, ListaCoordenada[1].X, ListaCoordenada[1].Y);

        }


        //Calculo los puntos del poligono
        public void CalcularLineaPiligono(float x1, float y1, float x2, float y2)
        {
            code1 = CalcularCodigo(x1, y1);
            code2 = CalcularCodigo(x2, y2);


            CalcularPendiente(x1, y1, x2, y2);


            if (code1 == "0000" && code2 == "0000")
            {
                puntosPoligonoRecortado.Add(new PointF(x1, y1));
                puntosPoligonoRecortado.Add(new PointF(x2, y2));
                return;
            }
            else if (code1 == "0000")
            {
                puntosPoligonoRecortado.Add(new PointF(x1, y1));
                puntosPoligonoRecortado.Add(CalcularPuntos(code2, x2, y2));
                return;


            }
            else if (code2 == "0000")
            {
                puntosPoligonoRecortado.Add(CalcularPuntos(code1, x1, y1));
                puntosPoligonoRecortado.Add(new PointF(x2, y2));

                return;

            }

            for (int i = 0; i < 4; i++)
            {
                if (code1[i] == '1' && code2[i] == '1')
                {
                    return;
                }
            }

            puntosPoligonoRecortado.Add(CalcularPuntos(code1, x1, y1));
            puntosPoligonoRecortado.Add(CalcularPuntos(code2, x2, y2));

        }

        //Calcula los puntos recortados
        public PointF CalcularPuntos(string auxCode, float x1, float y1)
        {
            float x = 0;
            float y = 0;


            PointF coordenada = new PointF();

            //$$x=x_0+(y-y_0)/m$$
            //$$y=y_0+m(x-x_0)$$

            switch (auxCode)
            {
                case "1001":
                    y = Ymax;
                    x = x1 + (Ymax - y1) / pendiente;
                    if (x < Xmin)  // si sigue fuera, recorta por izquierda
                    {
                        x = Xmin;
                        y = y1 + pendiente * (Xmin - x1);
                    }
                    coordenada.X = x;
                    coordenada.Y = y;
                    break;
                case "1000":
                    y = Ymax;
                    x = x1 + (Ymax - (y1)) / pendiente;

                    coordenada.X = x;
                    coordenada.Y = y;
                    break;
                case "1010":
                    y = Ymax;
                    x = x1 + (Ymax - y1) / pendiente;
                    if (x > Xmax)  // si sigue fuera, recorta por derecha
                    {
                        x = Xmax;
                        y = y1 + pendiente * (Xmax - x1);
                    }
                    coordenada.X = x;
                    coordenada.Y = y;
                    break;
                case "0001":
                    x = Xmin;
                    y = y1 + pendiente * (Xmin - (x1));

                    coordenada.X = x;
                    coordenada.Y = y;
                    break;
                case "0010":
                    x = Xmax;
                    y = y1 + pendiente * (Xmax - (x1));

                    coordenada.X = x;
                    coordenada.Y = y;
                    break;
                case "0101":
                    y = Ymin;
                    x = x1 + (Ymin - y1) / pendiente;
                    if (x < Xmin)
                    {
                        x = Xmin;
                        y = y1 + pendiente * (Xmin - x1);
                    }
                    coordenada.X = x;
                    coordenada.Y = y;
                    break;
                case "0100":
                    y = Ymin;
                    x = x1 + (Ymin - (y1)) / pendiente;

                    coordenada.X = x;
                    coordenada.Y = y;

                    break;

                case "0110":
                    y = Ymin;
                    x = x1 + (Ymin - y1) / pendiente;
                    if (x > Xmax)
                    {
                        x = Xmax;
                        y = y1 + pendiente * (Xmax - x1);
                    }
                    coordenada.X = x;
                    coordenada.Y = y;
                    break;
            }
            return coordenada;
        }

        //Recorta la figura
        public void RecortarFigura(PictureBox picCanvas, PointF[] arreglo)
        {
            string auxCode = "";
            DibujarFigura(picCanvas);

            for (int i = 0; i < arreglo.Length; i++)
            {
                auxCode = CalcularCodigo(arreglo[i].X, arreglo[i].Y);
                //Calculando la pendiente 
                if (i < arreglo.Length - 1)
                {
                    CalcularLineaPiligono(arreglo[i].X, arreglo[i].Y, arreglo[i + 1].X, arreglo[i + 1].Y);
                }
                else if (i == arreglo.Length - 1)
                {
                    CalcularLineaPiligono(arreglo[i - 1].X, arreglo[i - 1].Y, arreglo[i].X, arreglo[i].Y);
                    CalcularLineaPiligono(arreglo[i].X, arreglo[i].Y, arreglo[0].X, arreglo[0].Y);

                }
            }

            graphics = picCanvas.CreateGraphics();
            graphics.DrawPolygon(pen, puntosPoligonoRecortado.ToArray());
        }

        //Dibujar el poligono dinamicamente
        public void DibujarPoligono(PictureBox picCanvas, PointF[] arreglo)
        {
            DibujarFigura(picCanvas);
            graphics = picCanvas.CreateGraphics();
            graphics.DrawPolygon(pen, arreglo);
        }
    }
}
