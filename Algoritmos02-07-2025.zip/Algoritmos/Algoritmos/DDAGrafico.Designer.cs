﻿namespace Algoritmos
{
    partial class DDAGrafico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DDAGrafico));
            this.txtX1 = new System.Windows.Forms.TextBox();
            this.txtY1 = new System.Windows.Forms.TextBox();
            this.txtX2 = new System.Windows.Forms.TextBox();
            this.txtY2 = new System.Windows.Forms.TextBox();
            this.picCanva = new System.Windows.Forms.PictureBox();
            this.INICIAR = new System.Windows.Forms.Button();
            this.dataGrid = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.x2 = new System.Windows.Forms.Label();
            this.y2 = new System.Windows.Forms.Label();
            this.radio = new System.Windows.Forms.Label();
            this.resetear = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picCanva)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // txtX1
            // 
            this.txtX1.Location = new System.Drawing.Point(98, 63);
            this.txtX1.Name = "txtX1";
            this.txtX1.Size = new System.Drawing.Size(100, 22);
            this.txtX1.TabIndex = 0;
            // 
            // txtY1
            // 
            this.txtY1.Location = new System.Drawing.Point(98, 100);
            this.txtY1.Name = "txtY1";
            this.txtY1.Size = new System.Drawing.Size(100, 22);
            this.txtY1.TabIndex = 1;
            // 
            // txtX2
            // 
            this.txtX2.Location = new System.Drawing.Point(98, 138);
            this.txtX2.Name = "txtX2";
            this.txtX2.Size = new System.Drawing.Size(100, 22);
            this.txtX2.TabIndex = 2;
            // 
            // txtY2
            // 
            this.txtY2.Location = new System.Drawing.Point(98, 175);
            this.txtY2.Name = "txtY2";
            this.txtY2.Size = new System.Drawing.Size(100, 22);
            this.txtY2.TabIndex = 3;
            // 
            // picCanva
            // 
            this.picCanva.Location = new System.Drawing.Point(242, 28);
            this.picCanva.Name = "picCanva";
            this.picCanva.Size = new System.Drawing.Size(546, 610);
            this.picCanva.TabIndex = 4;
            this.picCanva.TabStop = false;
            this.picCanva.MouseClick += new System.Windows.Forms.MouseEventHandler(this.picCanva_MouseClick);
            // 
            // INICIAR
            // 
            this.INICIAR.Location = new System.Drawing.Point(24, 220);
            this.INICIAR.Name = "INICIAR";
            this.INICIAR.Size = new System.Drawing.Size(196, 23);
            this.INICIAR.TabIndex = 5;
            this.INICIAR.Text = "DDA";
            this.INICIAR.UseVisualStyleBackColor = true;
            this.INICIAR.Click += new System.EventHandler(this.INICIAR_Click);
            // 
            // dataGrid
            // 
            this.dataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGrid.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid.Location = new System.Drawing.Point(820, 66);
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.RowHeadersWidth = 51;
            this.dataGrid.RowTemplate.Height = 24;
            this.dataGrid.Size = new System.Drawing.Size(195, 529);
            this.dataGrid.TabIndex = 6;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(24, 249);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(196, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Bresenham(Linea)";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(24, 278);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(196, 23);
            this.button2.TabIndex = 8;
            this.button2.Text = "Bresenham(Circunferencia)";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(24, 336);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(196, 24);
            this.button3.TabIndex = 9;
            this.button3.Text = "Figura(Relleno)";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(71, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "x1:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(70, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 16);
            this.label2.TabIndex = 11;
            this.label2.Text = "y1:";
            // 
            // x2
            // 
            this.x2.AutoSize = true;
            this.x2.BackColor = System.Drawing.Color.Transparent;
            this.x2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.x2.Location = new System.Drawing.Point(70, 138);
            this.x2.Name = "x2";
            this.x2.Size = new System.Drawing.Size(23, 16);
            this.x2.TabIndex = 12;
            this.x2.Text = "x2:";
            // 
            // y2
            // 
            this.y2.AutoSize = true;
            this.y2.BackColor = System.Drawing.Color.Transparent;
            this.y2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.y2.Location = new System.Drawing.Point(70, 178);
            this.y2.Name = "y2";
            this.y2.Size = new System.Drawing.Size(24, 16);
            this.y2.TabIndex = 13;
            this.y2.Text = "y2:";
            // 
            // radio
            // 
            this.radio.AutoSize = true;
            this.radio.BackColor = System.Drawing.Color.Transparent;
            this.radio.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radio.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.radio.Location = new System.Drawing.Point(47, 138);
            this.radio.Name = "radio";
            this.radio.Size = new System.Drawing.Size(47, 16);
            this.radio.TabIndex = 14;
            this.radio.Text = "Radio:";
            // 
            // resetear
            // 
            this.resetear.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.resetear.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.resetear.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.resetear.Location = new System.Drawing.Point(819, 598);
            this.resetear.Margin = new System.Windows.Forms.Padding(0);
            this.resetear.Name = "resetear";
            this.resetear.Size = new System.Drawing.Size(196, 23);
            this.resetear.TabIndex = 15;
            this.resetear.Text = "Resetear";
            this.resetear.UseVisualStyleBackColor = false;
            this.resetear.Click += new System.EventHandler(this.resetear_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(47, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 16);
            this.label3.TabIndex = 16;
            this.label3.Text = "Lados:";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(24, 307);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(196, 23);
            this.button4.TabIndex = 17;
            this.button4.Text = "Bresenham(Elipse)";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(24, 366);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(196, 24);
            this.button5.TabIndex = 18;
            this.button5.Text = "Relleno +1";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(24, 396);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(196, 24);
            this.button6.TabIndex = 19;
            this.button6.Text = "Cohen Sutherland(Linea)";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(24, 426);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(196, 58);
            this.button7.TabIndex = 20;
            this.button7.Text = "Sutherland Hodgman(Poligono)";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(24, 490);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(196, 24);
            this.button8.TabIndex = 21;
            this.button8.Text = "Curvas Bézier";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(24, 520);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(196, 24);
            this.button9.TabIndex = 22;
            this.button9.Text = "B-splines ";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button10.Location = new System.Drawing.Point(608, 548);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(157, 32);
            this.button10.TabIndex = 23;
            this.button10.Text = "Recortar Poligono";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // DDAGrafico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1041, 650);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.resetear);
            this.Controls.Add(this.radio);
            this.Controls.Add(this.y2);
            this.Controls.Add(this.x2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGrid);
            this.Controls.Add(this.INICIAR);
            this.Controls.Add(this.picCanva);
            this.Controls.Add(this.txtY2);
            this.Controls.Add(this.txtX2);
            this.Controls.Add(this.txtY1);
            this.Controls.Add(this.txtX1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(1059, 697);
            this.MinimumSize = new System.Drawing.Size(1059, 697);
            this.Name = "DDAGrafico";
            this.Text = "Algoritmos";
            ((System.ComponentModel.ISupportInitialize)(this.picCanva)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtX1;
        private System.Windows.Forms.TextBox txtY1;
        private System.Windows.Forms.TextBox txtX2;
        private System.Windows.Forms.TextBox txtY2;
        private System.Windows.Forms.PictureBox picCanva;
        private System.Windows.Forms.Button INICIAR;
        private System.Windows.Forms.DataGridView dataGrid;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label x2;
        private System.Windows.Forms.Label y2;
        private System.Windows.Forms.Label radio;
        private System.Windows.Forms.Button resetear;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
    }
}