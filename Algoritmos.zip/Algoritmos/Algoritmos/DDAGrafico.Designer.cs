﻿namespace Algoritmos
{
    partial class DDAGrafico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DDAGrafico));
            this.txtX1 = new System.Windows.Forms.TextBox();
            this.txtY1 = new System.Windows.Forms.TextBox();
            this.txtX2 = new System.Windows.Forms.TextBox();
            this.txtY2 = new System.Windows.Forms.TextBox();
            this.picCanva = new System.Windows.Forms.PictureBox();
            this.INICIAR = new System.Windows.Forms.Button();
            this.dataGrid = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.x2 = new System.Windows.Forms.Label();
            this.y2 = new System.Windows.Forms.Label();
            this.radio = new System.Windows.Forms.Label();
            this.resetear = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picCanva)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // txtX1
            // 
            this.txtX1.Location = new System.Drawing.Point(98, 63);
            this.txtX1.Name = "txtX1";
            this.txtX1.Size = new System.Drawing.Size(100, 22);
            this.txtX1.TabIndex = 0;
            // 
            // txtY1
            // 
            this.txtY1.Location = new System.Drawing.Point(98, 100);
            this.txtY1.Name = "txtY1";
            this.txtY1.Size = new System.Drawing.Size(100, 22);
            this.txtY1.TabIndex = 1;
            // 
            // txtX2
            // 
            this.txtX2.Location = new System.Drawing.Point(98, 138);
            this.txtX2.Name = "txtX2";
            this.txtX2.Size = new System.Drawing.Size(100, 22);
            this.txtX2.TabIndex = 2;
            // 
            // txtY2
            // 
            this.txtY2.Location = new System.Drawing.Point(98, 175);
            this.txtY2.Name = "txtY2";
            this.txtY2.Size = new System.Drawing.Size(100, 22);
            this.txtY2.TabIndex = 3;
            // 
            // picCanva
            // 
            this.picCanva.Location = new System.Drawing.Point(242, 28);
            this.picCanva.Name = "picCanva";
            this.picCanva.Size = new System.Drawing.Size(546, 410);
            this.picCanva.TabIndex = 4;
            this.picCanva.TabStop = false;
            // 
            // INICIAR
            // 
            this.INICIAR.Location = new System.Drawing.Point(24, 220);
            this.INICIAR.Name = "INICIAR";
            this.INICIAR.Size = new System.Drawing.Size(196, 23);
            this.INICIAR.TabIndex = 5;
            this.INICIAR.Text = "DDA";
            this.INICIAR.UseVisualStyleBackColor = true;
            this.INICIAR.Click += new System.EventHandler(this.INICIAR_Click);
            // 
            // dataGrid
            // 
            this.dataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGrid.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid.Location = new System.Drawing.Point(820, 66);
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.RowHeadersWidth = 51;
            this.dataGrid.RowTemplate.Height = 24;
            this.dataGrid.Size = new System.Drawing.Size(195, 321);
            this.dataGrid.TabIndex = 6;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(24, 249);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(196, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Bresenham(Linea)";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(24, 278);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(196, 23);
            this.button2.TabIndex = 8;
            this.button2.Text = "Bresenham(Circunferencia)";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(24, 307);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(196, 24);
            this.button3.TabIndex = 9;
            this.button3.Text = "Figura(Relleno)";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(71, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "x1:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(70, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 16);
            this.label2.TabIndex = 11;
            this.label2.Text = "y1:";
            // 
            // x2
            // 
            this.x2.AutoSize = true;
            this.x2.BackColor = System.Drawing.Color.Transparent;
            this.x2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.x2.Location = new System.Drawing.Point(70, 138);
            this.x2.Name = "x2";
            this.x2.Size = new System.Drawing.Size(23, 16);
            this.x2.TabIndex = 12;
            this.x2.Text = "x2:";
            // 
            // y2
            // 
            this.y2.AutoSize = true;
            this.y2.BackColor = System.Drawing.Color.Transparent;
            this.y2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.y2.Location = new System.Drawing.Point(70, 178);
            this.y2.Name = "y2";
            this.y2.Size = new System.Drawing.Size(24, 16);
            this.y2.TabIndex = 13;
            this.y2.Text = "y2:";
            // 
            // radio
            // 
            this.radio.AutoSize = true;
            this.radio.BackColor = System.Drawing.Color.Transparent;
            this.radio.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radio.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.radio.Location = new System.Drawing.Point(47, 138);
            this.radio.Name = "radio";
            this.radio.Size = new System.Drawing.Size(47, 16);
            this.radio.TabIndex = 14;
            this.radio.Text = "Radio:";
            // 
            // resetear
            // 
            this.resetear.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.resetear.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.resetear.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.resetear.Location = new System.Drawing.Point(820, 402);
            this.resetear.Margin = new System.Windows.Forms.Padding(0);
            this.resetear.Name = "resetear";
            this.resetear.Size = new System.Drawing.Size(196, 23);
            this.resetear.TabIndex = 15;
            this.resetear.Text = "Resetear";
            this.resetear.UseVisualStyleBackColor = false;
            this.resetear.Click += new System.EventHandler(this.resetear_Click);
            // 
            // DDAGrafico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1041, 450);
            this.Controls.Add(this.resetear);
            this.Controls.Add(this.radio);
            this.Controls.Add(this.y2);
            this.Controls.Add(this.x2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGrid);
            this.Controls.Add(this.INICIAR);
            this.Controls.Add(this.picCanva);
            this.Controls.Add(this.txtY2);
            this.Controls.Add(this.txtX2);
            this.Controls.Add(this.txtY1);
            this.Controls.Add(this.txtX1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(1059, 497);
            this.MinimumSize = new System.Drawing.Size(1059, 497);
            this.Name = "DDAGrafico";
            this.Text = "Algoritmos";
            ((System.ComponentModel.ISupportInitialize)(this.picCanva)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtX1;
        private System.Windows.Forms.TextBox txtY1;
        private System.Windows.Forms.TextBox txtX2;
        private System.Windows.Forms.TextBox txtY2;
        private System.Windows.Forms.PictureBox picCanva;
        private System.Windows.Forms.Button INICIAR;
        private System.Windows.Forms.DataGridView dataGrid;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label x2;
        private System.Windows.Forms.Label y2;
        private System.Windows.Forms.Label radio;
        private System.Windows.Forms.Button resetear;
    }
}