﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Algoritmos
{
    public class BresenhamLinea
    {
        private int x1;
        private int y1;
        private int x2;
        private int y2;
        private float k;
        private float pendiente;
        private float p;
        private float deltax;
        private float deltay;
        private Graphics graphics;

        public List<Puntos> puntos = new List<Puntos>();



        public void CargarDatos(TextBox puntox1, TextBox puntoy1, TextBox puntox2, TextBox puntoy2)
        {
            x1 = int.Parse(puntox1.Text);
            y1 = int.Parse(puntoy1.Text);
            x2 = int.Parse(puntox2.Text);
            y2 = int.Parse(puntoy2.Text);
            pendiente = (float)(y2 - y1) / (float)(x2 - x1);
            deltax = Math.Abs(x2 - x1);
            deltay = Math.Abs(y2 - y1);
            k = (float)Math.Max(Math.Abs(deltax), Math.Abs(deltay));
            puntos.Add(new Puntos(x1, y1)); 
        } 

        public void ElejirValorPendiente()
        {
            p = (Math.Abs(pendiente) > 0 && Math.Abs(pendiente) < 1) ? 2f * deltay - deltax : 2f * deltax - (deltay);
        }

        public void CrearPunto()
        {
            ElejirValorPendiente();

            if (pendiente < 1)
            {
                forma1PuntosCrear();
            }
            else
            {
                forma2PuntosCrear();
            }
        }

        public void forma1PuntosCrear()
        {
            for (int i = 0; i < k; i++)
            {
                if (p < 0)
                {
                    x1 = x1 + 1;
                    puntos.Add(new Puntos(x1, y1));
                    p = p + 2f * deltay;
                }
                else
                {
                    y1 = y1 + 1;
                    x1 = x1 + 1;
                    puntos.Add(new Puntos(x1, y1));
                    p = p + 2f * deltay - 2f * deltax;
                }
            }
        }

        public void forma2PuntosCrear()
        {
            for (int i = 0; i < k; i++)
            {
                if (p < 0)
                {
                    y1 = y1 + 1;
                    puntos.Add(new Puntos(x1, y1));
                    p = p + 2f * deltax;
                }
                else
                {
                    y1 = y1 + 1;
                    x1 = x1 + 1;
                    puntos.Add(new Puntos(x1, y1));
                    p = p + 2f * deltax - 2f * deltay;
                }
            }
        }

        public void Dibujar(PictureBox picCanvas, float x, float y)
        {
            Pen pen = new Pen(Color.Black, 2);
            graphics = picCanvas.CreateGraphics();
            //Dibujar cada 100 miliseg
            graphics.DrawRectangle(pen, x * 10f, y * 10f, 1, 1);
            Thread.Sleep(500);
        }


    }
}
