﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;

namespace Algoritmos
{
    public class DDA
    {
        private int x1;
        private int y1;
        private int x2;
        private int y2;
        private int k;
        public float[] x;
        public float[] y;
        private float pendiente;
        private Graphics graphics;

        public List<Puntos> puntos = new List<Puntos>();


        public void CargarDatos(TextBox puntox1, TextBox puntoy1, TextBox puntox2, TextBox puntoy2)
        {
            x1 = int.Parse(puntox1.Text);
            y1 = int.Parse(puntoy1.Text);
            x2 = int.Parse(puntox2.Text);
            y2 = int.Parse(puntoy2.Text);
            pendiente = (float)(y2 - y1) / (float)(x2 - x1);
            ValorABSMayor();
        }

        public bool Pendiente()
        {
            if(pendiente >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void ValorABSMayor()
        {
            int deltaX = x2 - x1;
            int deltaY = y2 - y1;
            k = (Math.Abs(deltaX) > Math.Abs(deltaY)) ? Math.Abs(deltaX) : Math.Abs(deltaY);
        }

        public void Puntos()
        {
            float[] puntosX = new float[k];
            float[] puntosY = new float[k]; 

            puntosX[0] = (float)x1;
            puntosY[0] = (float)y1;

            bool formaFormula = Pendiente();
            float aux = Aumento();

            for (int i = 1; i < k; i ++)
            {
                if (formaFormula)
                {
                    puntosX[i] = (float)Math.Round(Formula5(aux));
                    puntosY[i] = y1 + i;
                    aux += 1f / pendiente;
                }
                else
                {
                    puntosY[i] = (float)Math.Round(Formula4(aux));
                    puntosX[i] = x1 + i;
                    aux += pendiente;
                }
            }

            //Agrego los puntos

            for (int i = 0; i < k; i++)
            {
                puntos.Add(new Puntos(puntosX[i], puntosY[i]));
            }

        }

        public void Dibujar(PictureBox picCanvas, float x, float y)
        {
            Pen pen = new Pen(Color.Black, 2);
            graphics = picCanvas.CreateGraphics();
            //Dibujar cada 100 miliseg
            graphics.DrawRectangle(pen, x * 10f, y * 10f, 1, 1);
            Thread.Sleep(500);
        }

        public float Aumento()
        {
            float aux = 0;

            if (Pendiente())
            {
                return aux = x1;
            }
            else
            {
                return aux = y1;
            }

        }

        public float Formula4(float y)
        {
            return y + pendiente;
        }

        public float Formula5(float x)
        {
            return x + 1f / pendiente;
        }

        


    }
}
