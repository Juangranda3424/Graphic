﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Algoritmos
{
    public class BresenhamCircunferencia
    {
        private float Radio;
        private float XCentro;
        private float YCentro;
        private float p;
        public List<Puntos> puntos = new List<Puntos>();
        private Graphics graphics;


        public void CargarDatos(float xCentro, float yCentro, float radio)
        {
            XCentro = xCentro;
            YCentro = yCentro;
            Radio = radio;
            p = 1 - Radio;
        }

        public void ProcesoIterativo()
        {
            int x = 0;
            int y = (int)Radio;
            float p = 1 - Radio;

            while (x <= y)
            {
                // Simetría en los 8 octantes con respecto al centro (XCentro, YCentro)
                puntos.Add(new Puntos(XCentro + x, YCentro + y));
                puntos.Add(new Puntos(XCentro + y, YCentro + x));
                puntos.Add(new Puntos(XCentro - x, YCentro + y));
                puntos.Add(new Puntos(XCentro - y, YCentro + x));
                puntos.Add(new Puntos(XCentro - x, YCentro - y));
                puntos.Add(new Puntos(XCentro - y, YCentro - x));
                puntos.Add(new Puntos(XCentro + x, YCentro - y));
                puntos.Add(new Puntos(XCentro + y, YCentro - x));

                // Actualización de la variable de decisión y del punto
                if (p < 0)
                {
                    p = p + 2 * x + 3;
                }
                else
                {
                    p = p + 2 * (x - y) + 5;
                    y--;
                }

                x++;
            }
        }


        public void Dibujar(PictureBox picCanvas, float x, float y)
        {
            Pen pen = new Pen(Color.Black, 2);
            graphics = picCanvas.CreateGraphics();
            //Dibujar cada 100 miliseg
            graphics.DrawRectangle(pen, x, y, 1, 1);
            Thread.Sleep(200);
        }
    }
}
