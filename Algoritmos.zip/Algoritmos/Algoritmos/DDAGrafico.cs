﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Algoritmos
{
    public partial class DDAGrafico : Form
    {
        public DDAGrafico()
        {
            InitializeComponent();
            radio.Visible = false;
            resetear.FlatStyle = FlatStyle.Flat;
            resetear.FlatAppearance.BorderSize = 0;
            resetear.BackColor = Color.Black;
        }

        private DDA dda = new DDA();
        private BresenhamLinea bresenhamLinea = new BresenhamLinea();
        private BresenhamCircunferencia bresenhamCircunferencia = new BresenhamCircunferencia();

        private void CargarDatos()
        {


            dataGrid.ColumnCount = 2;
            dataGrid.ColumnHeadersVisible = true;
            DataGridViewCellStyle columnHeaderStyle = new DataGridViewCellStyle();

            columnHeaderStyle.BackColor = Color.Beige;
            columnHeaderStyle.Font = new Font("Verdana", 10, FontStyle.Bold);
            dataGrid.ColumnHeadersDefaultCellStyle = columnHeaderStyle;

            //No permite modificar, eliminar y que se añada
            dataGrid.AllowUserToAddRows = false;
            dataGrid.AllowUserToDeleteRows = false;
            dataGrid.ReadOnly = true;

            //Quita la columna que aparece a la izquierda
            dataGrid.RowHeadersVisible = false;
            dataGrid.Columns[0].Name = "X";
            dataGrid.Columns[1].Name = "Y";
            dataGrid.Columns[0].Width = dataGrid.Width / 2;
            dataGrid.Columns[1].Width = dataGrid.Width / 2;

        }

        private void LimpiarPantalla()
        {
            //Limpiar DataGridView
            dataGrid.Rows.Clear();
            dataGrid.Columns.Clear();
            //Limpiar PictureBox
            picCanva.Refresh();
            //Limpiar Campos 
            txtX1.Text = "";
            txtX2.Text = "";
            txtY1.Text = "";
            txtY2.Text = "";
            CargarDatos();
        }

        private void ControlesVisiblesBresenhamCirculo()
        {
            radio.Visible = true;
            y2.Visible = false;
            x2.Visible = false;
            txtY2.Visible = false;
        }

        private void ControlesVisiblesBresenhamLineaDDA()
        {
            radio.Visible = false;
            y2.Visible = true;
            x2.Visible = true;
            txtY2.Visible = true;
        }


        private void INICIAR_Click(object sender, EventArgs e)
        {
            try
            {
                ControlesVisiblesBresenhamLineaDDA();
                dda.CargarDatos(txtX1, txtY1, txtX2, txtY2);
                //Limpiar Puntos
                dda.puntos.Clear();
                //Llenar dataos
                dda.Puntos();
                LimpiarPantalla();
                foreach (var punto in dda.puntos)
                {
                    dataGrid.Rows.Add(punto.X, punto.Y);
                    dda.Dibujar(picCanva, punto.X, punto.Y);
                }
            }
            catch
            {
                MessageBox.Show("Ingrese todos los datos correctamente");
            }

        }


        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                ControlesVisiblesBresenhamLineaDDA();
                bresenhamLinea.puntos.Clear();
                bresenhamLinea.CargarDatos(txtX1, txtY1, txtX2, txtY2);
                bresenhamLinea.CrearPunto();
                LimpiarPantalla();
                foreach (var punto in bresenhamLinea.puntos)
                {
                    dataGrid.Rows.Add(punto.X, punto.Y);
                    bresenhamLinea.Dibujar(picCanva, punto.X, punto.Y);
                }
            }
            catch
            {
                MessageBox.Show("Ingrese todos los datos correctamente");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                ControlesVisiblesBresenhamCirculo();
                bresenhamCircunferencia.puntos.Clear();
                bresenhamCircunferencia.CargarDatos((float)picCanva.Width/2f+float.Parse(txtX1.Text), (float)picCanva.Height / 2f + float.Parse(txtY1.Text), float.Parse(txtX2.Text));
                bresenhamCircunferencia.ProcesoIterativo();
                LimpiarPantalla();
                foreach (var punto in bresenhamCircunferencia.puntos)
                {
                    dataGrid.Rows.Add(punto.X, punto.Y);
                    bresenhamCircunferencia.Dibujar(picCanva, punto.X, punto.Y);
                }
            }
            catch
            {
                MessageBox.Show("Ingrese todos los datos correctamente");
            }

        }

        private void resetear_Click(object sender, EventArgs e)
        {
            LimpiarPantalla();
        }
    }
}
