﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Algoritmos
{
    using System.Collections.Generic;
    using System.Drawing;
    using System.Threading.Tasks;
    using System.Windows.Forms;

    public class RellenoFigura
    {
        private Graphics graphics;
        private Pen pen = new Pen(Color.Black, 3);
        private Bitmap canvasBitmap;
        public Queue<Point> cola = new Queue<Point>();

        public void CalcularPuntos(PictureBox picCanvas, int lados, float xcentro, float ycentro)
        {
            float radio = 60;
            PointF puntoCentro = new PointF(xcentro, ycentro);
            DibujarPoligono(picCanvas, puntoCentro, radio, lados);
        }

        public void DibujarPoligono(PictureBox picCanvas, PointF centro, float radio, int lados)
        {
            canvasBitmap = new Bitmap(picCanvas.Width, picCanvas.Height);
            graphics = Graphics.FromImage(canvasBitmap);
            graphics.Clear(Color.White);

            PointF[] puntos = new PointF[lados];
            for (int i = 0; i < lados; i++)
            {
                double angulo = i * 2 * Math.PI / lados - Math.PI / 2;
                float x = centro.X + radio * (float)Math.Cos(angulo);
                float y = centro.Y + radio * (float)Math.Sin(angulo);
                puntos[i] = new PointF(x, y);
            }

            graphics.DrawPolygon(pen, puntos);
            picCanvas.Image = canvasBitmap;
        }

        // Versión asincrónica con animación
        public async Task RellenarAnimado(PictureBox picCanvas, int x, int y, Color colorRelleno)
        {
            if (canvasBitmap == null) return;

            Color colorObjetivo = canvasBitmap.GetPixel(x, y);
            if (colorObjetivo.ToArgb() == colorRelleno.ToArgb()) return;

            cola.Enqueue(new Point(x, y));

            while (cola.Count > 0)
            {
                Point p = cola.Dequeue();
                int px = p.X;
                int py = p.Y;

                if (px < 0 || py < 0 || px >= canvasBitmap.Width || py >= canvasBitmap.Height)
                    continue;

                if (canvasBitmap.GetPixel(px, py).ToArgb() != colorObjetivo.ToArgb())
                    continue;

                canvasBitmap.SetPixel(px, py, colorRelleno);
                picCanvas.Image = canvasBitmap;
                picCanvas.Refresh(); // actualiza la imagen

                // Añade los píxeles vecinos
                cola.Enqueue(new Point(px + 1, py));
                cola.Enqueue(new Point(px - 1, py));
                cola.Enqueue(new Point(px, py + 1));
                cola.Enqueue(new Point(px, py - 1));

                // Delay para visualizar el relleno
                await Task.Delay(1); // puedes ajustar este valor para más velocidad
            }
        }
    }

}
